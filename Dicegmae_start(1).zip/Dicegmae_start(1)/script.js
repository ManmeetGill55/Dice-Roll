const d = new Date();
document.getElementById("day").innerHTML = d;



document.getElementById('btn').addEventListener('click', function() {

    var dice1 = Math.floor(Math.random() * 6) + 1;
    var dice2 = Math.floor(Math.random() * 6) + 1;


    document.querySelector('.dices .dice:nth-child(1) img').src = `dice-${dice1}.svg`;
    document.querySelector('.dices .dice:nth-child(2) img').src = `dice-${dice2}.svg`;
    document.querySelector('.dices .dice:nth-child(1) .dice-label').textContent = `Dice 1: ${dice1}`;
    document.querySelector('.dices .dice:nth-child(2) .dice-label').textContent = `Dice 2: ${dice2}`;


    var total = dice1 + dice2;

   
    document.getElementById('total').textContent = total;


    if (total >= 8) {
        document.getElementById('more-than-8').textContent = 'You Win: Try Again!';
        document.getElementById('less-than-8').textContent = '';
    } else {
        document.getElementById('less-than-8').textContent = 'You Lose: Try Again!';
        document.getElementById('more-than-8').textContent = '';
    }


if (total >= 8) {
    document.querySelector('.message h3').textContent = 'You won: Try Again!';
} else {
    document.querySelector('.message h3').textContent = 'You Lose: Try Again!';
}
});